<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    <a class="text-muted" href="https://rsud.acehsingkilkab.go.id/" target="_blank"><strong>Team IT RSUD</strong></a> - <a
                        class="text-muted" href="https://rsud.acehsingkilkab.go.id/" target="_blank"><strong>All Right Reserved</strong></a> &copy;
                </p>
            </div>
        </div>
    </div>
</footer>
